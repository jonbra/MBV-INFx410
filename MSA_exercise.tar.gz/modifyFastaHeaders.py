import sys

# Input file name is in the first argument, 
# and output file name in the second
infile = sys.argv[1]
outfile = sys.argv[2]

# Open input file and read all lines
fh = open(infile,"r")
lines = fh.readlines()
fh.close()

# Put all lines into one long string with junk first line. 
# This makes splitting below more efficient

full_text = "junk\n"
for line in lines:
    full_text = full_text + line

# Split into list of Fasta sequences on "newline" and then ">"
list_of_fastas = full_text.split("\n>")

# Open file for writing output
fo = open(outfile,"w")

# Loop through all Fasta sequences
# Skip first item in list as this is junk added above
for fasta in list_of_fastas[1:]:

# Get lines of Fasta sequence into list
    lines_2 = fasta.split("\n")
# Fasta header is first line
    header = lines_2[0]
# The sequence is in all remaining lines  
    seq = ""
    for line_2 in lines_2[1:]:
        seq = seq + line_2 + "\n"

# Split header on "|" and get the RefSeq identifier in field 3
    header_fields = header.split("|")
    long_RefSeq_ID = header_fields[3]
# The RefSeq identifiers are on the form NP_001072831.1
# get rid of the . and everything behind it
    temp_list = long_RefSeq_ID.split(".")
    RefSeq_ID = temp_list[0]

# Print out without going to next line
    print "Processing", RefSeq_ID, 

# The species name is in the last field of the header
    last_field = header_fields[-1]

# Split on "[" and then on "]" to get the species
# Replace spaces with "_"
    temp_list = last_field.split("[")
    temp_name = temp_list[1]
    temp_list = temp_name.split("]")
    species_name = temp_list[0].replace(" ","_")

    print "from species:", species_name

# Write this Fasta sequence to file
    new_header = ">" + species_name + "_" + RefSeq_ID
    fo.write(new_header+"\n")
    fo.write(seq)
# End of loop here 

# Close output file and exit 
fo.close()

